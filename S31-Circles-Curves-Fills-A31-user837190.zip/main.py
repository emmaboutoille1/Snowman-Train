"""  
Name: Emma Boutoille
Date: October 15
S4.1 Circles, Curves, and Fill
A4.1 Snowman Express
""" 

# ----------------------------- Imports ------------------------
import turtle # import turtle

# ------------------- Window Setup ----------------
wn = turtle.Screen() # create window called wn
wn.setup(height=600, width=800) # set window size
wn.title("A4.1 Snowman Express") # Window title
wn.colormode(255) # set color mode for RGB values
wn.bgcolor(204, 250, 255)

# -------------------  Turtle Setup ------------------------
tia = turtle.Turtle() # create tia  
tia.speed(8) # set tia's speed to 8

pen = turtle.Turtle() # create a pen turtle to write text on the screen
pen.color("cyan") # set text color to red
pen.ht() # hide the turtle
penstyle = ("Arial", 10, "bold") # set the text style
# ------------------- Global Variables ---------------------
# variables for position size, colour, and fill colour

# ------------------- Functions ---------------------------
# Function for Circles (with parameters for position, size, colour, fill)
# Function for Arms (with parameters for position and angle)
# Function for nose (parameter for position)
# Function for hat(parameter for postion)
# Additional function as required

# Shape Functions For Snowman
def draw_circle(circle_radius, fill_color, border_color, circle_x, circle_y): # create a function to draw circles with parameters
  tia.pu() # lift pen up
  tia.goto(circle_x, circle_y) # move tia to circle_x, circle_y
  tia.pd() # put pen down
  tia.color(border_color, fill_color) # set color to parameters
  tia.begin_fill() # begin filling circle
  tia.circle(circle_radius) # draw a circle with a radius of circle_radius
  tia.end_fill() # stop filling circle

def draw_arms(arms_x, arms_x2): # create a function to draw arms with parameters
  tia.color("black", "brown") # set tia's border color to black and fill color to brown
  tia.pu() # lift pen up
  tia.setheading(135) # change tia's setheading to 135
  tia.goto(arms_x, 62) # move tia to arms_x, 62
  tia.pd() # put pen down
  tia.begin_fill() # start filling shape
  tia.fd(40) # move tia forward 40
  tia.lt(140) # rotate tia to the left by 140 degrees
  tia.fd(15) # move tia forward 15
  tia.lt(55) # rotate tia to the left by 55 degrees
  tia.fd(30) # move tia forward 30
  tia.end_fill() # stop filling shape
  tia.setheading(50) # change tia's setheading to 50
  tia.pu() # lift pen up
  tia.goto(arms_x2, 62) # move tia to arms_x, 62
  tia.pd() # put pen down
  tia.begin_fill() # start filling shape
  tia.fd(40) # move tia forward 40
  tia.rt(140) # rotate tia to the right by 140 degrees
  tia.fd(15) # move tia forward 15
  tia.rt(55) # rotate tia to the right by 55 degrees
  tia.fd(30) # move tia forward 30
  tia.end_fill() # stop filling shape

def draw_nose(nose_x, nose_y): # create a function to draw the nose with parameters
  tia.pu() # lift pen up
  tia.setheading(90) # change tia's setheading to 90
  tia.goto(nose_x, nose_y) # move tia to nose_x, nose_y
  tia.pd() # put pen down
  tia.color("black", "orange") # set tia's border color to black and fill color to orange
  tia.begin_fill() # start filling nose
  tia.fd(10) # move tia forward 10
  tia.rt(97) # rotate tia to the right by 97 degrees
  tia.fd(40) # move tia forward 40
  tia.rt(165) # rotate tia to the right by 165 degrees
  tia.fd(40) # move tia forward 40
  tia.end_fill() # stop filling nose

def draw_hat(hat_x, hat_x2): # create a function to draw the hat with parameters
  tia.pu() # lift pen up
  tia.setheading(0) # change tia's setheading to 0
  tia.pd() # put pen down
  tia.color("black") # set tia's color to black
  tia.begin_fill() # start filling hat
  draw_rectangle(0, "black", "black", hat_x, 135, 45, 5, 90, 5) # call on draw_rectangle function with parameters to draw the bottom part of the hat
  draw_rectangle(0, "black", "black", hat_x2, 148, 28, 5, 90, 30) # call on draw_rectangle function with parameters to draw the top part of the hat
  tia.end_fill() # stop filling hat

# Draw Snowman Function
def draw_snowman(): # create a function to draw a snowman with parameters
  circle_x = -67 # set starting x value for circle
  circle_y = -70 # set starting y value for circle
  circle_radius = 50 # set starting radius value for circle
  mouth_x = [-90, -83, -74, -64, -55, -47] # create a list to store x values for the mouth
  mouth_y = [103, 94, 88, 88, 94, 103] # create a list to store y values for the mouth
  button_x = [-69, -69, -69] # create a list to store x values for the buttons
  button_y = [68, 48, 28] # create a list to store y values for the buttons
  x_eyes = -77 # set starting x value for the eyes
  y_eyes = 118 # set starting y value for the eyes
  nose_x = -68 # set starting x value for the nose
  hat_x = -88 # set starting x value for the top part of the hat
  hat_x2 = -80 # set starting x value for the bottom part of the hat
  arms_x = -102 # set starting x value for the left arm
  arms_x2 = -32 # set starting x value for the right arm
  tia.setheading(0) # change tia's setheading to 0
  tia.width(1) # set tia's width to 1
  for i in range(3): # set loop to repeat based on the number of snowmen
    for j in range(3): # set loop to repeat based on the number of circles per snowman
      draw_circle(circle_radius, "white", "black", circle_x, circle_y) # call on draw_circle function with parameters to draw the body of the snowman
      circle_y += 75 # increase the y value of the circle's radius by 75
      circle_radius -= 10 # decrease the circle's radius by 10
    circle_radius = 50 # reset the circle's radius to 50
    circle_y = -70 # decrease the y value of the circle's radius by 70
    circle_x += 250 # increase the x value of the circle's radius by 250
  
  for i in range(3): # set loop to repeat based on the number of snowmen
    for j in range(2): # set loop to repeat based on the number of eyes per snowman
      draw_circle(3, "black", "black", x_eyes, y_eyes) # call on draw_circle function with parameters to draw the eyes
      x_eyes += 20 # increase the x value of the eyes by 20
    x_eyes += 210 # increase the x value of the eyes by 210

  for i in range(3): # set loop to repeat based on the number of snowmen
    draw_nose(nose_x, 105) # call on draw_nose functio with parameters to draw the nose
    nose_x += 250 # increase the x value of the nose by 250
    draw_hat(hat_x, hat_x2) # call on draw_hat function to draw the hat
    hat_x += 250 # increase the x value of the hat by 250
    hat_x2 += 250 # increase the x value of the hat by 250
    draw_arms(arms_x, arms_x2) # call on draw_hat function to draw the arms
    arms_x += 250 # increase the x value of the left arm by 250
    arms_x2 += 250 # increase the x value of the right arm by 250
  
  for i in range(6): # set loop to repeat based on the number of circles per mouth
    for j in range(3): # set loop to repeat based on the number of snowmen
      draw_circle(3, "black", "black", mouth_x[i], mouth_y[i]) # call on draw_circle function to draw the mouth
      mouth_x[i] += 250 # increase the mouth x values by 250
    
  for i in range(3): # set loop to repeat based on the number of snowmen
    for j in range(3): # set loop to repeat based on the number of buttons per snowman
      draw_circle(3, "black", "black", button_x[i], button_y[i]) # call on draw_circle function to draw the buttons
      button_x[i] += 250 # increase the x values of the buttons by 250

# Shape Functions For The Train
def draw_rectangle(rec_heading, rec_color, rec_fillcolor, rec_x, rec_y, rec_width, rec_radius, rec_angle, rec_height): # create a function to draw a rectangle with parameters
  tia.color(rec_color, rec_fillcolor) # set tia's border color to rec_color and fill color to rec_fillcolor
  tia.setheading(rec_heading) # chage tia's setheading to rec_heading
  tia.pu() # lift pen up
  tia.goto(rec_x, rec_y) # move tia to rec_x, rec_y
  tia.begin_fill() # start filling whatever is drawn below
  tia.pd() # put pen down
  for i in range(2): # set loop to repeat two times
    tia.fd(rec_width) # move tia forward rec_width
    tia.circle(rec_radius, rec_angle) # draw a circle with a radius of rec_radius and and angle of rec_angle
    tia.fd(rec_height) # move tia forward rec_height
    tia.circle(rec_radius, rec_angle) # draw a circle with a radius of rec_radius and and angle of rec_angle
  tia.end_fill() # end fill

def draw_rectangle2(rec_heading2, rec_color2, rec_fillcolor2, rec2_x, rec2_y, rec_width1, rec_width2, rec_height, rec_radius, rec_angle): # create a function to draw an irregular rectangle for the windows with parameters
  tia.pu() # lift pen up
  tia.setheading(rec_heading2) # change tia's setheading to rec_heading2
  tia.color(rec_color2, rec_fillcolor2) # set tia's border color to rec_color2 and fill color to rec_fillcolor2
  tia.goto(rec2_x,rec2_y) # move tia to rec2_x, rec2_y
  tia.pd() # put pen down
  tia.begin_fill() # start filling whatever is drawn below
  tia.fd(rec_width1) # move tia forward rec_width1
  tia.lt(90) # rotate tia to the left by 90 degrees
  tia.fd(rec_height) # move tia forward rec_height
  tia.circle(rec_radius,rec_angle) # draw a circle with a radius of rec_radius and and angle of rec_angle
  tia.fd(rec_width2) # move tia forward rec_width2
  tia.circle(rec_radius,rec_angle) # draw a circle with a radius of rec_radius and and angle of rec_angle
  tia.fd(rec_height) # move tia forward rec_height
  tia.end_fill() # end fill

def draw_triangle(triangle_color, triangle_fillcolor, triangle_size1, triangle_angle, triangle_size2, triangle_size3): # create a function to draw a triangle with parameters
  tia.pu() # lift pen up
  tia.color(triangle_color, triangle_fillcolor) # set tia's border color to triangle_color and fill color to triangle_fillcolor
  tia.goto(-520, -200) # move tia to -520, -200
  tia.pd() # put pen down
  tia.begin_fill() # start filling triangle
  tia.rt(144) # rotate tia to the right by 144 degrees
  tia.circle(-10, 90) # draw a circle with a radius of -10 and an angle of 90
  tia.lt(3) # rotate tia to the left by 3 degrees
  tia.fd(35) # move tia forward 35
  tia.lt(90) # rotate tia to the left by 90 degrees
  tia.fd(12) # move tia forward 12
  tia.lt(65) # rotate tia to the left by 65 degrees
  tia.fd(50) # move tia forward 50
  tia.lt(45) # rotate tia to the left by 45 degrees
  tia.fd(15) # move tia forward 15
  tia.lt(72) # rotate tia to the left by 72 degrees
  tia.fd(40) # move tia forward 40
  tia.end_fill() # stop filling triangle

def draw_trapezoid(): # create a function to draw a trapezoid
  tia.pu() # lift pen up
  tia.goto(-443, -34) # move tia to -443, -34
  tia.color("black", "cyan") # set tia's border color to black and fill color to cyan
  tia.begin_fill() # start filling shape
  tia.pd() # put pen down
  tia.setheading(75) # change tia's setheading to 75
  tia.fd(40) # move tia forward 40
  tia.lt(40) # rotate tia to the left by 40 degrees
  tia.fd(15) # move tia forward 15
  tia.lt(65) # rotate tia to the left by 65 degrees
  tia.fd(50) # move tia forward 50
  tia.lt(55) # rotate tia to the left by 55 degrees
  tia.fd(15) # move tia forward 15
  tia.lt(50) # rotate tia to the left by 50 degrees
  tia.fd(40) # move tia forward 40
  tia.end_fill() # stop filling shape

def draw_engine(): # create a function to draw the train engine
  rectangle_xvalues = [-520, -505, -425, -355, -345, -310, -355] # create a list to store the x values for the rectangles
  rectangle_yvalues = [-200, -130, -130, -130, -75, -75, -35] # create a list to store the y values for the rectangles
  rectangle_widthvalues = [290, 70, 60, 120, 15, 65, 120] # create a list to store the width values for the rectangles
  rectangle_radiusvalues = [10, 5, 5, 5, 5, 5, 5] # create a list to store the radius values for the rectangles
  rec_angle = 90 # starting angle value for the rectangles
  rectangle_heightvalues = [50, 85, 80, 85, 20, 20, 20] # create a list to store the height values for the rectangles
  for i in range(0,1): # set loop to repeat for list elements 0 and 1
    draw_rectangle(0, "black", "orange", rectangle_xvalues[i], rectangle_yvalues[i], rectangle_widthvalues[i], rectangle_radiusvalues[i], rec_angle, rectangle_heightvalues[i]) # call draw_rectangle function
  for i in range(1,4): # set loop to repeat for list elements 2, 3, and 4
    draw_rectangle(0, "black", "DeepPink", rectangle_xvalues[i], rectangle_yvalues[i], rectangle_widthvalues[i], rectangle_radiusvalues[i], rec_angle, rectangle_heightvalues[i]) # call draw_rectangle function
  for i in range(4,6): # set loop to repeat for list elements 5 and 6
    draw_rectangle(0, "black", "LightSkyBlue1", rectangle_xvalues[i], rectangle_yvalues[i], rectangle_widthvalues[i], rectangle_radiusvalues[i], rec_angle, rectangle_heightvalues[i]) # call draw_rectangle function
  for i in range(6,7): # set loop to repeat for list element 7
    draw_rectangle(0, "black", "orange", rectangle_xvalues[i], rectangle_yvalues[i], rectangle_widthvalues[i], rectangle_radiusvalues[i], rec_angle, rectangle_heightvalues[i]) # call draw_rectangle function

  circle_x = -490 # set starting x value for the circles
  circle_y = -230 # set starting y value for the circles
  circle_radius = 30 # set starting radius value for the circles
  tia.width(2) # set tia's width to 2
  for j in range (2):# set loop to repeat based on the number of small wheels on the engine
    for k in range(3): # set loop to repeat based on the number of circles per small wheel
      draw_circle(circle_radius, "tan3", "SaddleBrown", circle_x, circle_y) # call on draw_circle function to draw the two smaller wheels on the train engine
      circle_y += 8 # increase the y value of the circle by 8
      circle_radius -= 8 # decrease the radius value of the circle by 8
    circle_radius = 30 # reset the radius value to 30
    circle_y = -230 # reset the circle's y value to -230
    circle_x += 70 # ncrease the x value of the circle by 70
  
  circle_x = -285 # set starting x value for the circles
  circle_y = -230 # set starting y value for the circles
  circle_radius = 45 # set starting radius value for the circles
  for i in range(3): # set loop to repeat based on the number of circles per wheel
    draw_circle(circle_radius, "tan3", "SaddleBrown", circle_x, circle_y) # call on draw_circle function to draw the big wheel on the train engine
    circle_y += 8 # increase the y value of the circle by 8
    circle_radius -= 8 # decrease the radius value of the circle by 8
  
  # Draw the curve on top of the engine
  tia.width(1) # set tia's width to 1
  tia.color("black", "cyan") # set tia's border color to black and fill color to cyan
  tia.pu() # lift pen up
  tia.setheading(90) # change tia's setheading to 90
  tia.goto(-372, -40) # move tia to -372, -40
  tia.pd() # put pen down
  tia.begin_fill() # start filling shape
  tia.circle(23, 175) # draw a circle with a radius of 23 and an angle of 175
  tia.end_fill() # stop filling shape

  # Draw the steam pipe
  draw_trapezoid() # call on draw_trapezoid function

  # Drawing the motor
  tia.pu() # lift pen up
  tia.setheading(90) # change tia's setheading to 90
  tia.goto(-530, -153) # move tia to -530, -153
  tia.pd() # put pen down
  tia.color("black", "orange") # set tia's border color to black and fill color to orange
  tia.begin_fill() # start filling shape
  tia.fd(10)
  tia.circle(-15,106)
  tia.setheading(180) # change tia's setheading to 180
  tia.goto(-510, -47) # move tia to -510, -47
  tia.fd(20) # move tia forward 20
  tia.circle(10, 50)
  tia.circle(75, 60)
  tia.circle(65, 30)
  tia.end_fill() # stop filling shape

  # Drawing the ramp at the front of the train
  draw_triangle("black", "DeepPink", 10, 60, 60, 52) # call on draw_triangle function to draw the ramp at the front of the train

  # Drawing the text on the engine
  pen.pu() # lift pen up
  pen.goto(-330, -105) # move tia to -330, -105
  pen.pd() # put pen down
  pen.st() # show tia
  pen.write("Snowman", font = penstyle) # write the text on the engine
  pen.pu() # lift pen up
  pen.goto(-325, -120) # move tia to -325, -120
  pen.pd() # put pen down
  pen.write("Express", font = penstyle) # write the text on the engine
  pen.ht() # hide pen turtle
  
def draw_tracks(): # create a function to draw the train tracks
  tia.pu() # lift pen up
  tia.goto(562,-230) # move tia to 562, -230
  tia.pd() # put pen down
  draw_rectangle(180, "black", "brown", 560, -232, 1152, 2, 90, 2) # call on draw rectangle function 
  tia.pu() # lift pen up
  tia.goto(562,-239) # move tia to 562, -239
  tia.pd() # put pen down
  tia.lt(90) # rotate tia to the left by 90 degrees
  tia.fd(5) # move tia forward 5
  tia.rt(90) # rotate tia to the right by 90 degrees
  tia.fd(20) # move tia forward 20
  rec_x = 538 # set the x value for the rectangles to 538
  rec_y = -249 # set the y value for the rectangles to -249
  x_value = 513 # set tia's x value to 513
  y_value = -244 # set tia's y value to 244
  for i in range(23): # set loop to repeat 23 times
    draw_rectangle(0, "black", "brown", rec_x, rec_y, 20, 4, 90, 2) # call on draw rectangle function 
    rec_x -= 50 # decrease the x value of the rectangle by 50
  tia.width(2) # set tia's width to 2
  tia.color("brown") # set tia's color to brown
  for j in range(23): # set loop to repeat 23 times
    tia.pu() # lift pen up
    tia.goto(x_value, y_value) # move tia to x_value, y_value
    tia.pd() # put pen down
    tia.fd(20) # move tia forward 20
    x_value -= 50 # decrease tia's x value by 50
  tia.pu() # lift pen up
  tia.setheading(180) # change tia's setheading to 180
  tia.goto(-588,-244) # move tia to -588, -244
  tia.pd() # put pen down
  tia.fd(5) # move tia forward 5
  tia.rt(90) # rotate tia to the right by 90 degrees
  tia.fd(10) # move tia forward 10
  tia.ht() # hide tia

# Train Sections Functions
def draw_car(): # create a function to draw the train cars
  bottomrectangle_colors = ["red", "lawngreen", "yellow"] # create a list to store the color values for the bottom rectangles
  middlerectangle_colors = ["lime green", "MediumPurple", "DeepSkyBlue"] # create a list to store the color values for the middle and top rectangles
  car_x1 = [-150, 100, 350] # create a list to store the x values for the bottom rectangles
  car_x2 = [-150, 100, 350] # create a list to store the x values for the middle rectangles
  car_x3 = [-153, 97, 347] # create a list to store the x values for the top rectangles
  car_x4 = [-140, 112, 364] # create a list to store the x values for the top left windows
  car_x5 = [-85, 166, 417] # create a list to store the x values for the top middle windows
  car_x6 = [-30, 221, 472] # create a list to store the x values for the top right windows
  car_x7 = [-100, 152, 404] # create a list to store the x values for the bottom left windows
  car_x8 = [10, 261, 512] # create a list to store the x values for the bottom right windows
  car_x9 = [-45, 206, 457] # create a list to store the x values for the bottom middle train windows
  car_x10 = [-192, -161, 60, 90, 310, 340, 560] # create a list to store the x values for the connectors
  circle_x1 = [-90, -98, -106] # create a list to store the x values for the left wheel
  circle_radius = [30, 22, 14] # create a list to store the radius values for the wheels
  circle_x2 = [17, 9, 1] # create a list to store the x values for the right wheel
  # Draw bottom rectangle
  tia.setheading(0) # change tia's setheading to 0
  for i in range(3): # set loop to repeat 3 times
    draw_rectangle(0, "black", bottomrectangle_colors[i], car_x1[i], -200, 170, 10, 90, 30) # call draw_rectangle function to draw the bottom rectangles
    draw_rectangle(0, "black", middlerectangle_colors[i], car_x2[i], -150, 170, 1, 90, 100) # call draw_rectangle function to draw the middle rectangles
    draw_rectangle(0, "black", middlerectangle_colors[i], car_x3[i], -47, 175, 5, 90, 10) # call draw_rectangle function to draw the top rectangles
    draw_rectangle2(0, "black", "LightSkyBlue1", car_x4[i], -80, 40, 30, 15, 5, 90) # call draw_rectangle2 function to draw the top left windows
    draw_rectangle2(0, "black", "LightSkyBlue1", car_x5[i], -80, 40, 30, 15, 5, 90) # call draw_rectangle2 function to draw the top middle windows
    draw_rectangle2(0, "black", "LightSkyBlue1", car_x6[i], -80, 40, 30, 15, 5, 90) # call draw_rectangle2 function to draw the top right windows
    draw_rectangle2(180, "black", "LightSkyBlue1", car_x7[i], -85, 40, 30, 25, 5, 90) # call draw_rectangle2 function to draw the bottom left windows
    draw_rectangle2(180, "black", "LightSkyBlue1", car_x8[i], -85, 40, 30, 25, 5, 90) # call draw_rectangle2 function to draw the bottom right windows
    draw_rectangle2(180, "black", "LightSkyBlue1", car_x9[i], -85, 40, 30, 40, 5, 90) # call draw_rectangle2 function to draw the bottom middle windows
  for i in range(3): # set loop to repeat 3 times
    for j in range(3): # set loop to repeat 3 times
      tia.width(2) # set tia's width to 2
      draw_circle(circle_radius[i], "tan3", "SaddleBrown", circle_x1[i], -200) # call on function draw_circle to draw the left wheel of the train cars
      draw_circle(circle_radius[i], "tan3", "SaddleBrown", circle_x2[i], -200) # call on function draw_circle to draw the right wheel of the train cars
      circle_x1[i] += 250
      circle_x2[i] += 250
  for i in range(7): # set loop to repeat 7 times
    tia.width(1) # set tia's width to 1
    draw_rectangle(90, "black", "snow3", car_x10[i], -190, 25, 5, 90, 20) # call draw_rectangle function to draw the connectors
  
# Final Train Function
def draw_train(): # create a function to draw the train
  draw_engine() # call on draw_engine function
  draw_car() # call on draw_car function
  draw_tracks() # call on draw_tracks function

# --------------------- Main Program ----------------------
# set variable values
# call the function
draw_snowman() # call on draw_snowman function
draw_train() # call on draw_train function
